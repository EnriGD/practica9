 /**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Enrique Gómez Díaz
 * @date 15 noviembre
 * @brief normalizar un vector
 *
 */

#include <iostream>
#include <vector>
#include <cmath>

/**
* @brief funcion que normaliza un vector entre dos valores
* @param1 vector de reales
* @param2 numero real
* @param3 numero real
* @return si se puede normalizar o no
*/
bool MinMax(std::vector<double>& vector,const double maximo, const double minimo){
  double maxi = vector[0];
  double mini = vector[0];
  
  for(int j = 1; j < vector.size(); j++){
    if(vector[j] < mini){
      mini = vector[j];
    }
    if(vector[j] > maxi){
      maxi = vector[j];
    }
  }

  if(vector.size() == 0 || maxi == mini){
    return false;
  }
  for(int i = 0; i < vector.size(); i++){
    vector[i] = minimo + (maximo - minimo) * (vector[i] - mini) / (maxi - mini);
  }
  return true;
}

int main(){
  /**
  *Se inicializan las variables y se le dan valores
  */
  std::vector<double> vector;
  vector.push_back(1.0);
  vector.push_back(2.0);
  vector.push_back(3.0);
  double maximo = 5.0;
  double minimo = 4.0;

  std::cout << MinMax(vector, maximo, minimo) << std::endl;
  return 0;
}
