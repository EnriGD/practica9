 /**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Enrique Gómez Díaz
 * @date 15 noviembre
 * @brief calcular distancia entre dos vectores
 *
 */

#include <iostream>
#include <vector>
#include <cmath>

/**
* @brief funcion que calcula la distancia entre dos vectores tras comprobar que son del mismo tamaño
* @param vector1 vector de reales
* @param vector2 vector de reales
* @return distancia entre los dos vectores
*/
double distancia(const std::vector<double>& vector1, const std::vector<double>& vector2){
  double resultado {0};
  if (vector1.size() != vector2.size()){
    return -1.0;
  } 
  for(int i = 0; i < vector1.size(); i++){
    resultado += (vector1[i] - vector2[i]) * (vector1[i] - vector2[i]);
  }
	
  return sqrt(resultado);
}


int main(){
  /**
  * Se declaran los vectores y se le añaden los valores
  */
  std::vector<double> vector1;
  std::vector<double> vector2;
  vector1.push_back(1.0);
  vector1.push_back(0.0);
  vector2.push_back(0.0);
  vector2.push_back(1.0);
  /**
  * Se llama a la funcion pasando como parámetros los dos vectores
  */
  std::cout << distancia(vector1, vector2) << std::endl;
  return 0;
}
